from setuptools import setup, find_packages

setup(
    name='SEfunctions',
    version='0.1.0',
    description='Spectroscopic Ellipsometry and Oscillator Models',
    author='Nandan, Alex',
    packages=find_packages(),
    install_requires=[
        'numpy',
        'pandas'
    ],
)
