# SEfunctions/core.py
import numpy as np
import pandas as pd

def Bruggeman_EMA_Roussel(M1, M2, c):
    wv = M1['Wavelength (nm)'].to_numpy()
    N1, N2 = M1['N'].to_numpy(), M2['N'].to_numpy()
    p = N1 / N2
    b = 0.25 * ((3*c - 1) * ((1/p) - p) + p)
    z = b + np.sqrt(b*b + 0.5)
    e = z * N1 * N2
    e1, e2 = e.real, e.imag
    mag = np.sqrt(e1*e1 + e2*e2)
    n = np.sqrt((mag + e1)/2)
    k = np.sqrt((mag - e1)/2)
    df = pd.DataFrame({'Wavelength (nm)': wv, 'N': n + 1j*k})
    df.name = f"EMA_{M1.name}_{M2.name}_{c:.2f}"
    return df

def Snells_Law(Structure, AOI):
    Nmat = np.stack([df["N"].to_numpy() for df in Structure])
    L, P = Nmat.shape
    angles = np.zeros((L,P), dtype=complex)
    angles[0] = np.radians(AOI)
    for i in range(1, L):
        angles[i] = np.arcsin((Nmat[i-1]/Nmat[i]) * np.sin(angles[i-1]))
    return angles

def fresnel_coefficients(N, angles):
    n1, n2 = N[:-1], N[1:]
    t1, t2 = angles[:-1], angles[1:]
    cos1, cos2 = np.cos(t1), np.cos(t2)
    ds = n1*cos1 + n2*cos2
    dp = n2*cos1 + n1*cos2
    rs = (n1*cos1 - n2*cos2)/ds
    ts = (2*n1*cos1)/ds
    rp = (n2*cos1 - n1*cos2)/dp
    tp = (2*n1*cos1)/dp
    return rs, rp, ts, tp

def Scattering_Matrix(N, angles, d, lam, r, t):
    L, P = N.shape
    d = d[:,None]; lam=lam[None,:]
    E = (2*np.pi/lam)*N[1:-1]*d*np.cos(angles[1:-1])
    prop = np.zeros((L-2,P,2,2), dtype=complex)
    prop[:,:,0,0] = np.exp(-1j*E)
    prop[:,:,1,1] = np.exp( 1j*E)
    interf = np.zeros((L-1,P,2,2), dtype=complex)
    interf[:,:,0,0] = 1/t; interf[:,:,0,1] = r/t
    interf[:,:,1,0] = r/t; interf[:,:,1,1] = 1/t
    S = interf[0]
    for i in range(1, L-1):
        S = S @ prop[i-1] @ interf[i]
    return S

def SE_Sim(Structure, AOI, d, write_data=False, NCS=True):
    wv = Structure[0]['Wavelength (nm)'].to_numpy()
    Nmat = np.stack([df["N"].to_numpy() for df in Structure])
    angles = Snells_Law(Structure, AOI)
    rs, rp, ts, tp = fresnel_coefficients(Nmat, angles)
    Ss = Scattering_Matrix(Nmat, angles, d, wv, rs, ts)
    Sp = Scattering_Matrix(Nmat, angles, d, wv, rp, tp)
    Rp = Sp[:,1,0]/Sp[:,0,0]
    Rs = Ss[:,1,0]/Ss[:,0,0]
    rho = np.conj(Rp/Rs)
    psi = np.arctan(np.abs(rho)).real
    delta = np.unwrap(np.angle(rho))
    Nval = np.cos(2*psi).real
    C = (np.sin(2*psi)*np.cos(delta)).real
    S = (np.sin(2*psi)*np.sin(delta)).real
    if NCS:
        return pd.DataFrame({'Wavelength (nm)': wv, 'N': Nval, 'C': C, 'S': S})
    else:
        return pd.DataFrame({
            'Wavelength (nm)': wv,
            'Psi':   psi*180/np.pi,
            'Delta': delta*180/np.pi
        })

def Lorentz(E, An, Br, En, einf=1.0):
    E = np.array(E)
    numerator   = An * Br * En
    denominator = En**2 - E**2 - 1j * Br * E
    dielectric  = einf + numerator / denominator
    e1 = dielectric.real
    e2 = dielectric.imag
    df = pd.DataFrame({
        'Energy (eV)': E,
        'e1':          e1,
        'e2':          e2,
        'e':           dielectric
    })
    df.name = f"A_{An}_Br_{Br}_En_{En}_Einf_{einf}"
    df.attrs["source_info"] = {
        "model":   "Lorentz",
        "An":      An,
        "Br":      Br,
        "En":      En,
        "Einf":    einf
    }
    return df

def drude_epsilon(E, rho_n, tau_fs):
    hbar     = 6.582119569e-16
    eps0     = 8.854e-14
    tau      = tau_fs * 1e-15
    numerator   = -hbar**2
    denominator = eps0 * rho_n * (tau * E**2 + 1j * hbar * E)
    dielectric = numerator / denominator
    e1 = dielectric.real
    e2 = dielectric.imag
    df = pd.DataFrame({
        'Energy (eV)': E,
        'e1':          e1,
        'e2':          e2,
        'e':           dielectric
    })
    df.name = f"Drude_rho{rho_n}_tau{tau_fs}"
    df.attrs["source_info"] = {
        "model":   "Drude",
        "rho_n":   rho_n,
        "tau_fs":  tau_fs
    }
    return df

def Sellmeier(A_uv, A_ir, En, e_inf, E):
    UV_dielectric = A_uv / (En**2 - E**2)
    IR_dielectric = -A_ir / (E**2)
    e1 = UV_dielectric + IR_dielectric + e_inf
    e2 = np.zeros_like(E)
    dielectric = e1 + 0j
    df = pd.DataFrame({
        'Energy (eV)': E,
        'e1':          e1,
        'e2':          e2,
        'e':           dielectric
    })
    df.attrs["source_info"] = {
        "model":  "Sellmeier",
        "A_uv":   A_uv,
        "A_ir":   A_ir,
        "En":     En,
        "e_inf":  e_inf
    }
    df.name = f"Sellmeier_Auv_{A_uv}_Air_{A_ir}_En_{En}_Einf_{e_inf}"
    return df

def sumosscilator(df_list):
    E = df_list[0]["Energy (eV)"].values
    e1_total = sum(df["e1"].values for df in df_list)
    e2_total = sum(df["e2"].values for df in df_list)
    e_total  = e1_total + 1j * e2_total
    df = pd.DataFrame({
        "Energy (eV)": E,
        "e1":          e1_total,
        "e2":          e2_total,
        "e":           e_total
    })
    df.attrs["source_info"] = {
        "model":      "Composite",
        "components": [
            d.attrs.get("source_info", {"model": "Unknown"})
            for d in df_list
        ]
    }
    return df
